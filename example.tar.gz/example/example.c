#include <stdio.h>

int main(){
	printf("yes yes very good example message indeed");
	return 0;
}
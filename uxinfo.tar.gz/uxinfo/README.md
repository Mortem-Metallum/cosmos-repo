This is UXInfo (UniX Info, could someone come with a better name?). Its a very, VERY basic system information utility written in Bash (the Bourne Again SHell). This project is nowhere NEAR complete (well, I mean duh. Its only around ~400 lines long rn and most of it is just ASCII art).
Prerequisites to run UXInfo:

- A working POSIX environment (Windows users need MinGW, Cygwin, Git Bash or MSYS/MSYS2)
- Bash installed

Other than that, it should run fine.

Its Xsh. Its a UNIX shell. There's not much to say about it.

Compilation:

cd build          # Meson is really picky about in-source compilation

meson setup .. && ninja -C .
